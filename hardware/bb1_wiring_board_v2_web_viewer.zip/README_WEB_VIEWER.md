# BB1 Wiring Board v2 — Web Viewer Assets

## Contents
- `bb1_wiring_board_v2.glb`: Binary glTF 3D PCB model with 3D components, copper tracks/pads/zones, green soldermask, white silkscreen, and drill holes.
- `kicad/bb1_wiring_board_v2.kicad_sch` (+ `bb1_v2.kicad_sym`, `sym-lib-table`): Live interactive schematic source for KiCanvas.
- `kicad/bb1_wiring_board_v2.kicad_pcb` (+ `.kicad_pro`): Live interactive 2D PCB inspection source (layers, nets, tracks, pads, silkscreen) for KiCanvas.
- `bb1_wiring_board_v2.svg`: Static vector schematic fallback.
- `bb1_wiring_board_v2_bom.csv` / `.json`: Structured Bill of Materials for interactive BOM inspection.
- `bb1_wiring_board_v2_pins.csv` / `.json`: Complete 60-pin connection table.

## Side-by-Side Web Embed (3D GLB + Live Interactive Schematic / 2D PCB)

### 1. 3D Orbit / Zoom / Pan (`<model-viewer>` or Three.js / React Three Fiber)
```html
<script type="module" src="https://ajax.googleapis.com/ajax/libs/model-viewer/3.5.0/model-viewer.min.js"></script>
<model-viewer
  src="/bb1_wiring_board_v2.glb"
  camera-controls
  auto-rotate
  shadow-intensity="1"
  style="width: 100%; height: 500px;">
</model-viewer>
```

### 2. Live Interactive Schematic + 2D PCB Inspector (KiCanvas)
```html
<script type="module" src="https://kicanvas.org/kicanvas/kicanvas.js"></script>
<kicanvas-embed controls="full" theme="kicad">
  <kicanvas-source src="/kicad/bb1_wiring_board_v2.kicad_sch"></kicanvas-source>
  <kicanvas-source src="/kicad/bb1_wiring_board_v2.kicad_pcb"></kicanvas-source>
</kicanvas-embed>
```
